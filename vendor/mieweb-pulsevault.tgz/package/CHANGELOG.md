# Changelog

All notable changes to this project are documented here. The format follows
[Keep a Changelog](https://keepachangelog.com/en/1.1.0/); this project follows
semantic versioning once it reaches `1.0.0` — pre-1.0, minor bumps may include
breaking changes, called out explicitly below.

## [Unreleased]

## [0.8.0] - 2026-11-06

### Changed

- **web-ready:** an H.264 8-bit SDR video keeps its size, frame rate and bytes up to H.264 level
  5.2 (4096×2304, 4K at 60 fps), the format every browser plays: a 4K or 60 fps H.264 upload is
  only remuxed, no longer re-encoded down to 1920. `maxEdge` and `maxFrameRate` now apply to a
  video that is re-encoded for another reason (HEVC, HDR, AV1, VP9, …), and to H.264 past level 5.2.
- **web-ready:** re-encodes are much faster for the videos that need them most. A re-encoded
  video now comes out at most 30 fps (`maxFrameRate`, the rate the Pulse app records), its
  frames dropped before anything else runs (one whose rate can't be read keeps only frames at
  least a frame of the cap apart, never repeating one), and HDR is tone-mapped after it is scaled down
  rather than at its full size. An HEVC clip recorded in temporal layers (an iPhone's 60 and
  120 fps) is decoded from its 30 fps base layer alone, the frames past the cap never decoded;
  if that fails, the run is repeated over every frame. A video that conforms otherwise (every Pulse upload) keeps its
  bytes and its own frame rate, as before.

- **web-ready:** a video that needs no re-encode — every Pulse upload, a lossless remux, an
  audio-only conversion — and a poster frame no longer wait behind another upload's re-encode.
  Conversions run in two lanes: video re-encodes, `concurrency` at a time (default 1), and
  everything else, two at a time.

- **web-ready:** a run is no longer cut short by a limit worked out from the video's length: a
  run that stops moving forward through the video for `stallSeconds` (default 120) is killed,
  and `timeoutSeconds` defaults to an hour, as a backstop. A long conversion on a small or busy
  server is never killed while it makes progress.

### Added

- **web-ready:** `maxFrameRate` option (default `30`).
- **web-ready:** a video whose container and stream disagree about its colour range is fixed
  losslessly: the container is retagged with the stream's range in a remux (the same video
  bytes), instead of being re-encoded. MP3 audio is kept as it is, like AAC.
- **web-ready:** the partial output a run stopped part-way leaves behind (a restart mid-conversion)
  is removed by the next run over the same video.
- **web-ready:** `stallSeconds` and `onProgress` options; the status route reports `progress`
  (0–1) while a conversion runs (protocol 2.6).
- **web-ready:** `needsVideoReencode(filePath, options)`: whether `ensureWebReady` would re-encode
  a file's video, for a host scheduling conversions itself. Writes nothing.

## [0.7.2] - 2026-11-02

### Fixed

- **A full-range recording is no longer re-encoded.** Some Android phones record full-range
  H.264 (`yuvj420p`): a Pixel 6a's Pulse recordings are, from both cameras. The Pulse app joins a
  draft of such clips without re-encoding, so a plain back-camera pulse from that phone failed
  "already conforms" and was transcoded in full before `onUploadComplete` ran. Full range now
  counts as conforming when the container and the video agree on it: Chrome, Firefox and Safari
  on macOS, Safari in the iOS Simulator and Chrome on Android then show it in the same colours as
  limited range. Where they disagree (an MP4 `colr` box saying one range, the H.264 stream the
  other), iOS Safari follows the container and every other browser the stream, so that video is
  still re-encoded. ffprobe before FFmpeg 9 doesn't report the `colr` box's range, so it is read
  from the file; a box structure that can't be read far enough counts as disagreeing, and a
  first-frame probe that times out leaves the file as uploaded (`skipped`). A re-encode for any
  reason writes limited range.

## [0.7.1] - 2026-11-02

### Fixed

- **A Pulse recording held upright is no longer re-encoded.** A phone records portrait as its
  camera's landscape frame plus a rotation tag, and the Pulse app's joins keep that tag, so every
  portrait pulse from an iPhone failed "already conforms" and was transcoded in full before
  `onUploadComplete` ran: with `completeAfter`, a 3-minute pulse reached its host minutes late.
  A quarter-turn rotation tag now counts as conforming (every browser shows it upright), and the
  `maxEdge` cap is checked against the size a player shows. A re-encode for another reason still
  applies the rotation to the pixels, and a stream copy (a `moov` remux, a container change, an
  audio-only re-encode) keeps the tag.

## [0.7.0] - 2026-10-30

### Added

- **A poster for every video** (`webReady.poster`, on by default): a video that arrived without
  a thumbnail — a file from a host's own picker — gets one frame as its poster after the
  conversion, stored as a thumbnail `relatedTo` it, so `GET /artifacts/:artifactId/poster`
  serves it like a pulse's. A video whose pulse sent a thumbnail is left alone. A video stored
  before this gets its poster the first time it's asked for, in the background.
- `extractPosterFrame(path, { ffmpegPath })`: one frame of a video as a JPEG, at most 640 px.
- `storeArtifact` on the storage contract (and the local adapter): stores a finished artifact
  PulseVault made itself, ready and acknowledged, under `relatedTo`, only while that artifact is
  still the ready one of `relatedGeneration`. Resolves whether it stored it.
- `generated` on artifact metadata, `true` for one PulseVault made. `getPulse` (and so the poster
  route) prefers a thumbnail the client sent over a generated one, whichever finished last.

### Changed

- **Hosts with `webReady` on now get posters without opting in**: each conversion is followed by
  a poster frame (another ffmpeg run, a new thumbnail artifact and file per video), and
  `/artifacts/:artifactId/poster` answers 200 for videos it used to 404 for. Set
  `webReady: { poster: false }` to keep the old behaviour. A thumbnail still uploading holds the
  poster back until it finishes or is given up; one that arrives while the frame is made wins.

## [0.6.0] - 2026-10-12

Protocol 2.5 (`PROTOCOL.md` §7.4): 2.4 adds the https pairing link form (#83), 2.5 the conform
step's `webReady` result. `webReady` becomes a **conform** step: whatever video a
person uploads, PulseVault serves it in the one format the Pulse app records, and a Pulse upload
is left untouched (#84).

### Added

- **https pairing links** (#83): `buildUploadLink({ …, form: 'https' })`
  returns `https://mieweb.github.io/pulse/open#v=1&artifactId=…&server=…&token=…`,
  the same parameters as the `pulsecam://` form, in the fragment. It is a
  Universal Link / App Link: a phone camera opens it, Pulse opens straight
  from it when installed, and the page sends the person to the store when it
  isn't. Browsers never send the fragment, so the link host never receives the
  token. `PULSE_OPEN_URL` is exported. Without `form` the output is
  unchanged, `pulsecam://`, because Pulse releases from before the link host
  was claimed open the https form only through the page's button.
- **Conform target** (`CONFORM_TARGET`): faststart MP4, H.264 8-bit `yuv420p` (limited range)
  with even dimensions, SDR (HDR tone-mapped to BT.709; SDR colour tags kept), the longest edge at most `webReady.maxEdge` (default 1920; aspect ratio and
  orientation kept), rotation applied, AAC or no audio. `ensureWebReady` leaves a file already
  in it byte-for-byte (`none`), remuxes losslessly when only the container or `moov` position is
  off, and otherwise runs ffmpeg once, re-encoding only the off-target streams: HEVC and other
  codecs to H.264, 10-bit HDR (PQ/HLG) tone-mapped to SDR (FFmpeg 8's `scale`, or `zscale` on
  older builds), full-range video (iPhone screen recordings) to limited range, oversized video
  scaled down, Opus/PCM and other audio to AAC.
- **Container change**: a `.mov`, `.m4v`, `.webm`, `.mkv`, `.3gp` or `.avi` becomes a new
  `<id>.mp4` (`WebReadyAction` `conformed`). The artifact's stored file, `ext` and served
  `Content-Type` follow it; the artifact id and its URLs don't change. The sidecar switches
  first, then the original is deleted (`sourceExt` remembers it so `remove` cleans up after a
  crash). New patch fields `ext` and `webReady` (local adapter; the S3 adapter refuses them).
  `describeArtifact` reports the uploaded extension as `sourceExt` once it differs, and
  `uploadIdOf(meta)` names tus's upload by it, so a replayed hook's `ext` and `uploadId` still
  match `filename`.
- `webReady.timeoutSeconds` (default `60 + 10 ×` the duration in 1080p30 seconds, so 4K or high
  frame rates get proportionally longer, at most an hour since it comes from the upload's own
  metadata; set it explicitly for longer runs): a longer run is killed, the original
  kept, and `skipped` recorded with the reason.
- The conversion's result is recorded on the artifact: `GET /artifacts/:id/status` and
  `getStatus` report `webReady: { action, reason }` (protocol 2.5), and `describeArtifact`
  returns it.
- `core.conformAvailable()` (also on `fastify.pulseVaultCore`): `false` when `webReady` is off or
  ffmpeg/ffprobe are missing, for a host's health check.
- `createVideoValidator({ maxDurationSeconds? })`: a `validatePayload` hook that checks a video
  by its content with ffprobe (a video stream with a duration above zero, including a browser
  WebM without one in its header; a picture — PNG, JPEG, GIF, HEIC, a one-frame clip, counted
  from the first two packets when the container has no frame count — is not a video), refusing with `422 That file isn't a video.` or `That video is
  longer than the limit of …` (the configured limit exactly: "1 minute 1 second"); falls back to `sniffVideo` (`ftyp`, EBML or RIFF AVI) without
  ffprobe. Also exported: `probeVideo`, `webReadyAvailable`, `CONFORM_VIDEO_EXTENSIONS`.
- An upload over `maxUploadSize` is refused with `413 That file is larger than 500 MB.` instead
  of tus's "Maximum size exceeded".
- `webReady.probeTimeoutSeconds` and `createVideoValidator({ probeTimeoutSeconds })` (default 60):
  every ffprobe run over an upload is bounded; the validator refuses with `422 That video
  couldn't be checked in time.`
- Content types for `.webm`, `.mkv`, `.3gp` and `.avi`.
- While a video is being converted, `GET /artifacts/:id` is served with `max-age=0` instead of
  the configured `cache` (which may be `immutable`), so no client keeps the original bytes once
  the converted file replaces them.

### Changed

- The default video `allowedExtensions` are `.mp4`, `.mov`, `.m4v`, `.webm`, `.mkv`, `.3gp` and
  `.avi` (was `.mp4`). A host's own `allowedExtensions` still overrides them.
- A failed conversion is now recorded (`webReady: { action: "skipped", reason }`) as well as
  logged, and still not retried; a conversion that never recorded a result is resumed by the
  replay, as before.
- The local adapter's `remove` reads the sidecar itself (not its cache) and deletes the
  converted `<id>.mp4` and the uploaded file as well as the stored one. A converted video's bytes
  are always at `<id>.mp4`, and `resolve`/`getLocalPath` fall back to it when the sidecar's `ext`
  file is gone: across instances sharing a workspace, where the last sidecar write wins (as
  before; there is no cross-instance lock), a write from a copy older than a conversion still
  serves the converted file.
- A client that re-sends the final `PATCH` of a finished upload whose file a conversion replaced
  (a `.webm` conformed to `<id>.mp4`) gets `204`, as without a conversion: the local adapter's tus
  store reads such an upload as complete and takes its empty tail without a write.
- A `webReady` conversion needs the adapter's `generation`: an adapter with `getLocalPath` but no
  generation has its videos recorded `skipped` (`the storage adapter keeps no generation for this
  upload`). The local adapter gives one at `markReady` to an upload reserved before this release.
- Reservations run under the in-process sidecar lock, and `remove` deletes the sidecar last, so a new upload
  of a removed id never has its bytes deleted by the old removal. Each reservation gets a
  `generation` (`describeArtifact`), new every time the id is reserved.
- A conversion is installed in one patch under the sidecar lock: the runner converts into a temporary
  `.mp4` (`ensureWebReady(…, { install: false })`), then `patchArtifact` with `file` renames it
  onto the stored file, switches `ext`, records the result and deletes the original — only for
  the reservation the conversion began on (`generation`) and only while no other pass has
  recorded one (`unlessConverted`). When a condition doesn't hold, `patchArtifact` resolves
  `false`, changing nothing, and the runner drops its file.
- Completion work belongs to one reservation: a queued conversion checks, when its turn comes,
  that the id still names the upload it was queued for (and that it's finished); the
  acknowledgement is recorded only on that reservation; and a new upload of a removed id is never
  joined to the old one's work in progress.
- `GET /artifacts/:id` opens the file before sending headers, checks it's the file `send`
  described (inode, size, mtime), and resolves once more when it's gone or another file was
  renamed onto the path (a conversion just replaced it), instead of a 404, a cut-off response or
  headers that don't match the bytes; bytes this
  instance resolved under an extension storage no longer names are served with `max-age=0`.
- A failed run's recorded reason is `ffmpeg exited with code N`, never ffmpeg's output (which
  names server paths); an HDR video on an ffmpeg without tone mapping is left as uploaded
  (`skipped`, saying what's missing) rather than converted with wrong colours.
- The local adapter's `remove` decides from the sidecar alone, never its cache: an artifact
  another reader had cached is reported removed once, not twice.
- `webReady` needs an adapter with `describeArtifact` too (both built-in adapters have it).
- The local adapter's `getLocalPath` reads the sidecar, not its cache, so it names the current
  file after another instance removed the id and reserved it again.
- ffmpeg's capability queries (`-version`, `-h filter=scale`, `-filters`) are bounded (30 s).
- An `onArtifactEvent` observer that throws on `processed` is logged as its own failure; the
  recorded result still reaches `completeAfter`'s hook as `ctx.webReady`.
- A replayed `onUploadComplete` (the hook threw, or the process stopped) gets the recorded
  conversion result as `ctx.webReady` too, so a host naming the file from it (an `.mp4` once a
  WebM was conformed) gets it right on the retry.
- `web-ready-migrate.mjs` rerun after an interruption deletes an original the sidecar no longer
  names.
- `scripts/web-ready-migrate.mjs` conforms existing artifacts the same way, recording the result
  on each sidecar and switching a changed container to its `.mp4`. Run it with the server
  stopped.
- `transcode: false` records a file it leaves off-target (HEVC, oversized, non-AAC audio) as
  `skipped`, not `none`: `none` now means only that the file already conforms. (Was `none`.)
- A browser WebM's missing duration is found by streaming ffprobe's packet list and keeping
  only the latest end, never buffering it.
- An upload of deferred length that grows past `maxUploadSize` (a chunk with a length, or a
  chunked body cut off mid-stream) gets the same `413 That file is larger than …` message.
- An MP4-family `.mov`/`.m4v` that already conformed used to be served as is (`video/quicktime`,
  a type not every browser takes); it is now remuxed into an `.mp4`.

## [0.5.0] - 2026-10-05

Protocol 2.3 (`PROTOCOL.md` §7.4). What every host rebuilt around PulseVault
(#80), in the core: the shape of a pulse, a completion that survives a throw
or a restart, a lock on finished pulses, the token's own context, a status
route, background web-ready, a poster route and `getPulse`, and the content
types phones send. Two defaults change; both have an escape hatch.

### Changed (breaking)

- **A create must have the shape of a pulse** (`pulseShape`, on by default):
  a video with no `relatedTo`; a thumbnail, beat manifest or captions under
  its own id, `relatedTo` the video. With `createCapabilityAuthorize` the ids
  are also tied to the token: the video only under the token's own
  `artifactId`, the rest only `relatedTo` it. Before, one token could create
  any number of artifacts under ids the client picked, or take the video's
  own id with a thumbnail so the real video answered `409` for good. The
  Pulse app has always uploaded in this shape. For uploads that aren't
  pulses, pass `pulseShape: false` to the plugin or core *and* to
  `createCapabilityAuthorize`.
- **A create reclaims an idle unfinished upload of the same artifactId**
  (`reclaim`, `{ idleSeconds: 300 }` by default): an app killed mid-upload
  sends no TUS `DELETE`, so re-scanning the same link answered `409` until
  `retention` ran. Only an upload of the same kind and `relatedTo` is taken
  over (the same token authorized both), and only once the local adapter has
  seen no bytes for `idleSeconds`. `reclaim: false` keeps the old `409`.
- **`onUploadComplete` is at-least-once.** PulseVault records that the hook
  returned (`acknowledged` in the sidecar) and fires it again, with
  `ctx.replay: true`, for a finished artifact it never recorded: the hook
  threw, or the process stopped first. Every 300 seconds, with the first pass
  shortly after start (`replayCompletions`; `false` turns it off, and
  `core.replayCompletions()` / `fastify.pulseVaultCore.replayCompletions()`
  runs a pass on demand). Hosts must check their own record before writing
  it again. Finished sidecars written before this release read as acknowledged, so an
  upgrade replays nothing; one still uploading at the upgrade completes
  normally. A retried final `PATCH` no longer fires the hook a
  second time.
- **`authorize` gains the `status` phase** (`GET /artifacts/:id/status`).
  An exhaustive `switch` on the phase needs a case for it.
- **Content types**: the `.pulse` beat manifest is served as
  `application/json`, and `.mov`, `.m4v` and `.srt` — when a host allows them
  in `allowedExtensions`; the defaults stay what the Pulse app sends — as
  `video/quicktime`, `video/x-m4v` and `application/x-subrip`, instead of
  `application/octet-stream`, which `<video>` downloads instead of playing.

### Added

- **Hook context**: `authorize` and `onUploadComplete` receive `relatedTo`,
  `name`, `appVersion`, `filename`, `ext` and the token's `context`, so a
  host maps a finished file to its own record without reading storage back.
- **`context` in the capability token** (`issueCapabilityToken(id, secret,
  { context })`, the `ctx` claim, at most 1 KiB of JSON): an owner, a
  destination — signed, stored with the artifact at create (`authorize` may
  return `{ context }`), and handed to every hook, `getStatus` and `getPulse`.
  Most hosts need no table keyed by artifactId any more.
- **`GET /artifacts/:id/status`** and `core.getStatus(id)`: `unknown`,
  `uploading` (with `bytesReceived` against `size`), `processing` or
  `ready`, plus `acknowledged` and whatever the host recorded with
  `recordOutcome(id, outcome)`. Authorized as `status`;
  `createCapabilityAuthorize` grants it to the pairing token and a view token.
- **`webReady`**: the conversion `ensureWebReady` does, run by the core in
  the background after the final `PATCH` is answered, `concurrency` at a
  time, with a `processing` status meanwhile, a `processed` event when done,
  and `completeAfter: true` to hold `onUploadComplete` until the conversion
  has finished (`ctx.webReady` says what it did). Whether it finished is
  recorded on the sidecar (`converted`), so a conversion a restart
  interrupted is redone by the replay. Local storage only.
- **`lockWhenReady`**: a finished artifact, and anything `relatedTo` a
  finished video, can't be deleted through the routes (`403`); the host
  removes through `storage.remove` on its own terms.
- **`core.getPulse(videoId)`** → `{ video, thumbnail, captions, manifest }`
  and **`GET /artifacts/:videoId/poster`**, both from a relation index the
  adapters keep at reserve time (`storage.listRelated`), so neither scans
  storage and nothing is backfilled.
- **Storage adapter contract**: optional `describeArtifact`, `patchArtifact`
  and `listRelated`, and `context` in `reserveUpload` (both built-in
  adapters implement them). The local adapter's relation index lives at
  `.pulsevault/related/<videoId>/<artifactId>`; the S3 adapter's under the
  same key prefix.
- **`onArtifactEvent`**: `phase: "processed"` (with `webReady`), and
  `reason: "reclaimed"` on `remove`.
- **Fastify**: `fastify.pulseVaultCore` (`coreDecoratorName`) exposes
  `getStatus`, `getPulse`, `recordOutcome` and `replayCompletions`.
- **`examples/meteor-demo`** is now the reference host integration, shaped
  like a team app: people, destinations, a reserve that signs the owner and
  destination into the token, delivery from `onUploadComplete`, status
  polling, and video cards with posters — with no table of uploads, no shape
  check, no stale-upload cleanup and no content-type fix-up of its own.

## [0.4.2] - 2026-10-02

### Added

- **The Pulse logo and the store badges ship with the package**: the logo in
  full colour and one colour (`assets/pulse-logo.svg`,
  `assets/pulse-logo-mono.svg`), and the App Store and Google Play badges
  (`assets/badge-app-store.svg`, `assets/badge-google-play.png`), exported as
  `@mieweb/pulsevault/assets/*`. An app can put the logo on the button that
  opens Pulse and link the badges to Pulse's listings. See `assets/README.md`.

## [0.4.1] - 2026-09-30

### Fixed

- **`@mieweb/pulsevault/core` loads under Meteor again.** 0.4.0 read the
  protocol version from `package.json` at runtime with
  `createRequire(import.meta.url)`. That's valid ESM for Node, but Meteor
  compiles npm packages into its own module wrapper, which already declares
  `require` and can't compile `import.meta`, so a Meteor app crashed at boot
  (`SyntaxError: Identifier 'require' has already been declared`). `npm run
  build` now writes the version into `src/lib/protocol-version.gen.ts`
  (`scripts/gen-protocol-version.mjs`); `package.json` `pulseProtocol` is still
  the one place it's set, and a missing or malformed value now fails the build.

## [0.4.0] - 2026-09-30

Protocol 2.2 (`PROTOCOL.md` §7.4). Protocol 2 records the `uploadUnit`
removal below as the breaking change it is; clients built for protocol 1
can't pair with this release.

### Added

- **Read-only view links** (protocol 2.2). The pairing token is a full
  capability, so a watch link carrying it let anyone holding the link
  upload to the artifact or delete it. The new `issueViewLink` option turns
  on `POST {prefix}/artifacts/:id/view-link` (authorized as the new
  `"share"` phase): for a finished artifact it returns `{ token, expiresAt }`,
  a token that only opens the artifact and the artifacts `relatedTo` it
  (`GET ?token=`). The host decides each link's lifetime, or refuses one;
  PulseVault sets none. `createViewLinkIssuer` / `issueViewToken` /
  `verifyViewToken` implement it for capability tokens: view tokens carry
  `use: "view"`, are signed with a key derived from the same secret (so a
  verifier that predates them rejects one), and `createCapabilityAuthorize`
  accepts them only for `resolve`. `/capabilities` reports `viewLinks`, and
  `protocol/schemas/view-link.schema.json` defines the response.
- **Opt-in cleanup of abandoned uploads.** The `retention` option
  (`{ abandonedAfterSeconds, sweepIntervalSeconds? }`, on the plugin and
  `createPulseVaultCore`) sweeps on a timer, removing uploads left
  unfinished past the cutoff and the related artifacts (never videos) of a
  video that never finished; finished videos are never touched.
  `sweepAbandonedUploads` runs one sweep for your own scheduler. Storage
  adapters gain an optional `listArtifacts`, implemented by both built-in
  adapters.
- **`onArtifactEvent` reports removals:** `phase: "remove"`, with `reason:
  "deleted"` (`DELETE /artifacts/:id` or a TUS `DELETE`) or `"abandoned"` (the
  `retention` sweep), so a host keeping its own index of artifacts can drop
  one. A consumer that switches exhaustively on `phase` sees a new value.

- **The protocol is written down as files, and CI keeps it honest.**
  `protocol/schemas/*.schema.json` define `/capabilities`, pairing links,
  `Upload-Metadata`, the beat manifest, capability-token claims and the
  `Pulse-Client` header; `protocol/openapi.json` is generated from the
  route schemas (`npm run protocol`), and so are the field tables in
  `PROTOCOL.md`. `scripts/check-protocol.mjs` fails a change that alters the
  protocol without the right version bump (oasdiff decides what's breaking
  for the HTTP routes). The `protocol/` folder is published with the package.
- **`Pulse-Client` request header and `426 Upgrade Required`** (protocol
  2.1). A client that says its newest protocol is older than this server's
  oldest gets 426 with the supported range on uploads and artifact
  requests; `/capabilities` always answers. No header, no change.
- **`Upload-Metadata.appVersion`** (protocol 2.1): stored with the artifact
  by both storage adapters and reported on the `complete`/`reject` events
  (`PulseVaultArtifactEvent.appVersion`).
- **`protocolRevision`** in `/capabilities`: the spec revision, `major.minor`.
- **CI** (`.github/workflows/ci.yml`): tests on Node 22 and 24, the protocol
  checks, the e2e against Postgres, and the Pulse app's contract suite
  against each PR's build.

### Changed

- **A TUS `DELETE` is authorized as `"delete"`, not `"patch"`.** It now
  removes the artifact (below), the same as `DELETE /artifacts/:id`, so an
  `authorize` hook sees one phase for every removal — and a rejected one is
  reported on `onArtifactEvent` like any other rejected delete. If your hook
  allows `"patch"` but refuses `"delete"`, clients can no longer cancel an
  upload through TUS; allow `"delete"` for the artifact's own token.
- **Breaking: protocol 2.** `/capabilities` reports `protocolVersion: 2` and
  accepts protocol majors 2–2, read from the new `package.json`
  `pulseProtocol` field (`{ "version": "2.1", "min": 2, "max": 2 }`).

### Removed

- **Breaking: `uploadUnit` is gone — a pulse uploads as one video; beats are
  timestamps within it** (#64). A pulse is one video (the artifact named by
  the pairing link) plus its related captions, beat manifest and thumbnail;
  a beat is a `startMs`/`endMs` range inside that video, not an upload
  strategy (`PROTOCOL.md` §8). Concretely:
  - The `uploadUnit` option is removed from the Fastify plugin and from
    `createPulseVaultCore`. Passing it now throws a `TypeError` at boot
    ("`uploadUnit` was removed — delete the option") instead of being
    silently ignored — delete the option from your config.
  - `buildUploadLink` no longer accepts or emits an `uploadUnit` param.
    Links minted by older releases stay valid: clients ignore unknown params
    (`PROTOCOL.md` §3).
  - `GET /capabilities` no longer returns an `uploadUnit` field.
  - Needs Pulse 2.1.0 or later (mieweb/pulse#213) —
    older Pulse builds require `uploadUnit` in `/capabilities`.

### Fixed

- **A TUS `DELETE` removes the whole artifact.** It used to reach only the
  tus datastore, so PulseVault's sidecar stayed behind: the artifactId
  answered every later create with `409`, a finished upload deleted on the
  local adapter kept a `ready` sidecar pointing at nothing, and on S3 a
  finished upload wasn't deleted at all (aborting its completed multipart
  upload fails with `NoSuchUpload` before anything is removed). Termination
  now runs `storage.remove` under tus's per-upload lock — bytes, tus record
  and sidecar, in flight or finished. The S3 adapter's `remove` also deletes
  the incomplete `.part` object @tus/s3-store parks between PATCHes.

## [0.3.0] - 2026-09-16

### Changed

- **Breaking: Node.js 20 is no longer supported** (`engines.node` is now
  `>=22`). Node 20 reached end-of-life on 2026-04-30; Node 22 (maintenance
  LTS) and Node 24 (active LTS) remain supported.

## [0.2.0] - 2026-09-14

This release reworks the upload contract for genuine multi-tenant use — any
third party can implement a compatible server from `PROTOCOL.md` alone, not
just by reading this package's source. It bundles several breaking changes
into one release rather than spreading them across several; see "Upgrading"
in `OPERATIONS.md` for the migration path.

### Security

The `videoid` → `artifactId` / generic-route rework above introduced two
related authorization bugs in `core.ts`'s `PATCH`/`HEAD` handling. Both are
fixed in this same release; upgrade before this reaches a published version
if you've evaluated against an intermediate build.

- **`authorize` was never actually invoked for `PATCH`/`HEAD`/in-flight-`DELETE`
  under `{prefix}/upload/<id>`**, regardless of configuration — including the
  built-in `createCapabilityAuthorize`. The helper that recovered an
  artifactId from the tus resource URL for the `authorize` context assumed
  the wrong shape for the current `<kind>/<artifactId><ext>` tus id and never
  successfully extracted a UUID, so the "no artifactId, so allow" fallback
  silently took over on every such request. Since an artifactId is not a
  secret (it's carried in the pairing deep link/QR code by design, per
  `PROTOCOL.md` §3), this let anyone who had seen a pairing link write bytes
  into that upload with no token at all. Fixed by resolving the artifactId
  through the same parser the actual upload-completion path uses, and by
  making authorization-context resolution failure a hard reject rather than
  a silent allow (`PROTOCOL.md` §5.2).
- **A crafted multi-segment `PATCH` URL could write bytes to a different
  artifact than the one `authorize()` checked.** The `authorize`-context URL
  parser took the first path segment after `/upload/`, while `@tus/server`'s
  own request routing (which decides what's actually read/written) takes the
  URL's last segment — a divergence exploitable via extra path segments
  (accepted by the `/upload/*` wildcard route). A party holding a valid
  token for their own artifact could append a second, victim artifactId as a
  trailing segment: `authorize()` saw and approved their own id, while the
  request body landed on the victim's file. Fixed by resolving the
  authorization-context artifactId via the exact same last-segment
  extraction `@tus/server` itself uses (`PROTOCOL.md` §4.4, a new normative
  requirement on server implementations generally, not just this package).
- Both are covered by new regression tests in `test/plugin.test.mjs` that
  fail against the pre-fix code and pass against the fix.
- **Removed `s3rver`** (unmaintained) from the dev/test toolchain, clearing
  its open `npm audit` findings: its dependency chain carried high-severity
  advisories (`busboy`/`dicer`) and forced pinning `fast-xml-parser` via an
  `overrides` entry plus a hand-written API-compat shim. The S3 suite now runs
  against `test/mock-s3.mjs`, a zero-dependency in-memory S3 double
  implementing exactly the eleven operations the code under test uses. Unlike
  s3rver it enforces `If-None-Match: "*"` (412), so the adapter's atomic
  reserve collision guard is now genuinely exercised — a concurrent-reserve
  test that was impossible against s3rver has been added. The `ListParts` shim
  (s3rver never implemented it) is gone too.
- **5xx responses no longer echo internal error messages.** A `markReady`,
  `onUploadComplete`, or 5xx-class `validatePayload` failure now logs the real
  error server-side and returns a generic body, so a consumer's DB/storage error
  text (schema names, paths, infra detail) can't reach the uploading client. 4xx
  validation rejections (e.g. checksum mismatch) keep their descriptive messages.
- **Storage subdirectories are created with mode `0o750`** so the upload tree
  isn't world-readable under a permissive umask.

### Breaking

- **Node.js `>=20` is now required** (`engines.node` was `>=18`). Node 18 is
  past end-of-life; every dependency floor in this release is tested against
  20+ only.
- **The `fastify` peer-dependency floor rose from `^5.8.5` to `^5.12.1`**,
  which is the first release fixing GHSA-w2qp-rph6-63g4 (schema-validation
  bypass via root primitive coercion mismatch, moderate) and
  GHSA-3m5p-2c4r-xxw2 (`X-Forwarded-*` spoofing under `trustProxy`
  hop-count, moderate). Refreshing the lockfile alongside it also clears the
  transitive `find-my-way` HTTP/2 DDoS advisory (GHSA-c96f-x56v-gq3h, high)
  and the `fast-uri` host-confusion/SSRF advisory cluster (high).
- **Renamed `videoid` → `artifactId`** across the storage interface
  (`ReserveUploadParams`, `PulseVaultStorage` methods), the `authorize`
  context (`PulseVaultAuthorizeContext`), the `validatePayload`/
  `onUploadComplete` hook contexts, the `request.pulseVault` TypeScript
  augmentation (`./augment.ts` — a separate breaking change from the wire
  rename, since it's the published type surface, not the HTTP contract), and
  the deep-link query parameter built by `buildUploadLink`. `videoid`/
  `projectid` remain accepted as legacy aliases in `Upload-Metadata` — only
  the *primary* name changed, not backward compatibility for existing
  clients' requests.
- **Collapsed the per-kind routes into one generic route.** `GET/DELETE
  /:videoid` and `GET/DELETE /project/:projectid` are gone; replaced by
  `GET/DELETE /artifacts/:artifactId`, which resolves the kind from storage
  rather than the URL. This also means `kind=captions` artifacts (new, see
  below) don't need a third route pair.
- **`validateProjectPayload`/`onProjectUploadComplete` are deprecated** (not
  yet removed) in favor of the now-generic `validatePayload`/
  `onUploadComplete`, which receive `ctx.kind` and run for every artifact
  kind. Passing either deprecated option now emits a one-time
  `DeprecationWarning` at plugin registration.
- **`allowedExtensions` requires a `captions` default to be considered** if
  you were relying on the exact shape of the normalized object internally
  (public consumers passing `allowedExtensions` as documented are unaffected
  — the new key just has a default like `video`/`project` already did).

### Added

- **`name`** — an optional `Upload-Metadata` key carrying a free-form UTF-8
  display title for the artifact (e.g. the draft name typed on the capture
  device). Trimmed and hard-capped server-side (512 chars), persisted to the
  sidecar alongside `relatedTo`/`checksum`, and exposed via the new optional
  `getName` storage method (and `ReserveUploadParams.name`). Display-only
  metadata: it never influences storage paths, routing, or authorization, and
  consumers must escape it for their own output context. Optional everywhere,
  so older clients that don't send it and consumers that don't read it are
  unaffected. Documented in `PROTOCOL.md` §4.1 as a non-normative extension.
- **`kind: "captions"`** artifact type (default extension `.vtt`), running
  through the same generic `validatePayload`/`onUploadComplete` hooks as
  every other kind. WebVTT carries word-level inline cue timestamps
  (`<00:00:01.500>word`) for karaoke rendering, and both storage adapters
  serve `.vtt` artifacts with the `text/vtt` content type.
- **`relatedTo`** — an optional `Upload-Metadata` key (and matching
  `ReserveUploadParams`/storage field) linking one artifact to another (e.g.
  a merged video's captions/beat-manifest/thumbnail, or a clip belonging to a
  segment ordering manifest's session).
  Storage adapters expose it via the new optional `getRelatedTo` method.
- **`checksum`** — an optional `Upload-Metadata` key (`<algorithm>:<hex
  digest>`) verified post-upload via the new `createChecksumValidator`
  (local storage) / `createS3ChecksumValidator` (S3/R2) helpers, chainable
  with `createMp4Sniffer`. This is at-rest integrity verification on the
  finished file, not a per-chunk check — `@tus/server`'s installed version
  doesn't implement the TUS Checksum extension, which would have covered
  chunks in flight.
- **`src/lib/capability-token.ts`**: `issueCapabilityToken`,
  `verifyCapabilityToken`, `createCapabilityAuthorize` — a stateless,
  HMAC-signed capability-token scheme with `kid` (key rotation with an
  overlap window), `iat` (clock-skew tolerance), and `issuer` (cross-deployment
  replay protection) claims. Fully optional — bring your own `authorize` if
  you have existing auth.
- **`GET {prefix}/capabilities`** — unauthenticated discovery route reporting
  `protocolVersion`, `minSupportedVersion`/`maxSupportedVersion`,
  `uploadUnit`, `kinds`, `allowedExtensions`, `maxUploadSize`, and supported
  checksum algorithms. Lets independently-versioned deployments and clients
  detect compatibility before pairing.
- **`uploadUnit` plugin option** (`"segment" | "merged"`, default `"segment"`) —
  purely advertised via `/capabilities`; the operator declares which upload
  strategy this deployment expects, the client branches on it. Not enforced
  by the plugin. `"segment"` uploads each recorded clip plus an ordering
  manifest; `"merged"` uploads one pre-merged video plus its captions, a
  beat-timecode manifest, and a thumbnail. (A "beat" is a timecode range on
  the merged timeline, not an upload unit.)
- **`kind: "thumbnail"`** artifact type (default extensions `.jpg`/`.jpeg`/
  `.png`) — the pulse poster frame uploaded alongside a merged video, running
  through the same generic `validatePayload`/`onUploadComplete` hooks and a
  `thumbnail/` storage subdir like every other kind.
- **`buildUploadLink({ uploadUnit })`** (PROTOCOL.md §3, §8) — optional
  per-session override of the deployment-wide `uploadUnit`, carried on the
  pairing link itself instead of only `/capabilities`. Lets an operator run
  `"segment"` and `"merged"` sessions concurrently (staged rollout, A/B test,
  per-tenant policy) without racing a client's separate `/capabilities` fetch
  against a single, deployment-wide value. Fully backward compatible: omit it
  and a client falls back to `/capabilities` exactly as before.
- **`onArtifactEvent` plugin option** — one low-frequency hook (authorize
  rejection, completion, validation rejection — never per chunk) covering
  both ops metrics and a compliance audit trail from a single integration
  point.
- **`Protocol-Version` response header** on every route this plugin mounts.
- **`@mieweb/pulsevault/core`** — a framework-agnostic entry point with no
  Fastify dependency. `createPulseVaultCore(...)` returns a connect-style
  `handler(req, res, next?)` usable directly as Express middleware
  (`app.use(prefix, handler)`), Meteor middleware
  (`WebApp.connectHandlers.use(prefix, handler)`), or a bare
  `http.createServer` callback — same options, hooks, and storage adapters as
  the Fastify plugin (which is now itself a thin adapter over this core, so
  behavior can't drift between the two). See "Non-Fastify hosts" in
  `README.md`, and `examples/express-demo`/`examples/meteor-demo` for full
  runnable servers verified against the real frameworks.
  - As part of this, `PulseVaultAuthorize`/`PulseVaultValidatePayload`/
    `PulseVaultOnUploadComplete`'s `request` parameter is now typed as the
    generic `PulseVaultRequest` (just `{ headers }`) instead of
    `FastifyRequest` — `FastifyRequest` still satisfies it structurally, so
    untyped/inferred hook callbacks (the documented pattern) are unaffected;
    only an explicit `(request: FastifyRequest, ctx) => ...` annotation on
    one of these three hooks would need loosening.
- Bounded, insertion-order-evicting in-memory metadata cache in both storage
  adapters (`metaCacheLimit` option, default 10,000 entries) — previously
  unbounded for the life of the process.
- `S3Storage.readAll` — full-object read, used by `createS3ChecksumValidator`.
- `S3Storage.digestAll` — streams a finalized object through a hash digest
  without buffering the whole thing into memory first; the streaming
  counterpart to `readAll`, now used internally by
  `createS3ChecksumValidator` (see "Fixed" below).

### Changed

- Dependency floors bumped to current patch releases: `@fastify/send`
  `^4.1.1`, `@tus/s3-store` `^2.0.6`, AWS SDK `^3.1131.0`, TypeScript
  `^6.0.3`, `@types/node` `^25.9.6`. `@tus/server`/`@tus/file-store` stay
  deliberately pinned at `2.0.0` (Meteor `srvx` exports issue — see the
  Meteor compatibility entry below); `fastify-plugin` stays on `^5.1.0`
  (v6 is a major, out of scope for a security-motivated bump).
- Replaced `examples/rn-demo` with two focused Fastify examples:
  `examples/fastify-demo` (the smallest runnable server — no auth, local
  storage, QR pairing; start here) and `examples/fastify-auth-demo`
  (production-shaped reference — capability tokens always on, failing fast at
  boot without `PULSEVAULT_SECRET`, pulse-session grouping via `relatedTo`,
  WebVTT captions, Swagger UI, artifact-event feed). Both pairing pages
  are React (pinned ESM CDN builds, no bundler). Both examples are
  local-storage only; S3 wiring is documented in the README's S3 section
  rather than demonstrated in an example. `npm run e2e` now drives
  `fastify-auth-demo` and additionally asserts the fail-fast boot contract.
- `examples/fastify-auth-demo` gained a [Better Auth](https://better-auth.com)
  dashboard layer: the human-facing routes (`/deeplinks`, `/pulses`,
  `/events`, `/reserve`) require an email+password session, while the vault
  routes the Pulse app talks to stay capability-token authorized — two auth
  systems for two audiences, per PROTOCOL.md §5. The demo is Postgres-only,
  run through Docker Compose (`compose.yaml` + `Dockerfile`; `npm run db:up`
  + `npm start` for bare-metal dev against the same db), with one Prisma
  schema (`prisma/schema.prisma`, migrations committed and applied by
  `npm start`) holding both the auth tables and an **artifact index**:
  `onUploadComplete` writes each finished upload once, authorized deletes
  prune it, a boot-time reconcile keeps it honest against the filesystem
  sidecars (still the source of truth), and `/pulses` becomes one indexed
  query instead of a per-request sidecar crawl. `npm run e2e` provisions the
  compose db, applies migrations, and covers the 401 gate plus the
  sign-up/sign-in flow.

### Fixed

- **Artifact `GET`/`DELETE` handlers now fail closed.** They run on a hijacked
  socket, so a thrown storage error (S3 unreachable, disk fault) previously left
  the socket hung until timeout; each now emits a `500` (or destroys the socket
  if headers are already sent), mirroring the TUS handler. `GET` streams also
  catch a mid-stream read error instead of letting an unhandled `'error'` crash
  the process, and destroy the source stream on client disconnect so file
  descriptors aren't leaked. Covered by `test/fail-closed.test.mjs`.
- A consumer error carrying an out-of-range `statusCode` (e.g. `42`) now degrades
  to the handler's fallback status instead of crashing `res.writeHead`; a
  malformed request-target that `URL` can't parse returns `400` instead of an
  uncaught throw.
- Checksum verification requested against an adapter with no local path now
  reports `500` (server misconfiguration) instead of `422` (which wrongly
  implied the client's file was rejected).
- `verifyCapabilityToken` no longer throws on a token whose payload is valid
  JSON but not an object (e.g. the literal `null`) — it returns `null` like
  every other failure, per its single-failure-shape contract.
- Bearer-token extraction accepts the auth scheme case-insensitively per
  RFC 7235 (`bearer`/`BEARER`), not only the canonical `Bearer `.
- `maxUploadSize` enforcement and the in-progress-upload 404 behavior now
  have explicit test coverage proving bytes are rejected/hidden at the right
  point, not just implied by the implementation.
- **Meteor compatibility.** Meteor's bundler doesn't resolve `package.json`
  `"exports"` subpath maps, which broke both this package's own `"./core"`
  entry and, transitively, `@tus/server`'s dependency on `srvx` (which as of
  `@tus/server@2.1.0` ships *only* subpath exports, no legacy `main`
  fallback). Fixed two ways: `@tus/server`/`@tus/file-store` are pinned to
  `2.0.0` (the last release before the `srvx` migration — everything added
  in `2.1.0`–`2.4.1` was either the `srvx` migration itself, follow-up
  fixes for regressions it introduced, or one unused `exposedHeaders`
  option, so nothing this package relies on is lost); and plain root-level
  `core.js`/`core.d.ts`/`augment.js`/`augment.d.ts` files now ship alongside
  the `"exports"` map, so resolvers that ignore `"exports"` (Meteor's
  included) still find these entry points via ordinary relative-path
  resolution. Verified against a real Meteor 3.4 app: `WebApp.connectHandlers`
  resolves `@mieweb/pulsevault/core` cleanly and a full TUS
  create → PATCH → GET round-trip works.
- **Unbounded memory use during checksum validation.** `createChecksumValidator`
  read the whole finalized file into a single `Buffer` via `fs.readFile`
  before hashing; combined with the documented-supported `maxUploadSize:
  Infinity`, a large upload could exhaust process memory just to verify its
  checksum. Now streams the file through the hash via `createReadStream` +
  a stream pipeline. `createS3ChecksumValidator` had the same issue via
  `S3Storage.readAll`'s full-object buffer — now uses the new streaming
  `S3Storage.digestAll` instead.
- **Silent TOCTOU on S3-compatible backends without `IfNoneMatch` support.**
  `reserveUpload`'s conditional-write collision guard falls back to a
  weaker check-then-write on backends that reject `IfNoneMatch` (some
  S3-compatible stores) — this reopens the race between concurrent/retried
  creates
  for the same artifactId. There's no way to close it without an external
  lock, so this is now at least surfaced: a one-time `console.warn` fires
  per process the first time a deployment falls into this degraded mode.

[Unreleased]: https://github.com/mieweb/pulsevault/compare/v0.8.0...HEAD
[0.8.0]: https://github.com/mieweb/pulsevault/compare/v0.7.2...v0.8.0
[0.7.2]: https://github.com/mieweb/pulsevault/compare/v0.7.1...v0.7.2
[0.7.1]: https://github.com/mieweb/pulsevault/compare/v0.7.0...v0.7.1
[0.7.0]: https://github.com/mieweb/pulsevault/compare/v0.6.0...v0.7.0
[0.6.0]: https://github.com/mieweb/pulsevault/compare/v0.5.0...v0.6.0
[0.5.0]: https://github.com/mieweb/pulsevault/compare/v0.4.2...v0.5.0
[0.4.2]: https://github.com/mieweb/pulsevault/compare/v0.4.1...v0.4.2
[0.4.1]: https://github.com/mieweb/pulsevault/compare/v0.4.0...v0.4.1
[0.4.0]: https://github.com/mieweb/pulsevault/compare/v0.3.0...v0.4.0
[0.3.0]: https://github.com/mieweb/pulsevault/compare/v0.2.0...v0.3.0
[0.2.0]: https://github.com/mieweb/pulsevault/compare/v0.0.1...v0.2.0
